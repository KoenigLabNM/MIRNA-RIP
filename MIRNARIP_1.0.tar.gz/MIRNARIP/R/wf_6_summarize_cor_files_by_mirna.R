#' Summarizes the correlation files of single miRNA - target gene models
#' 
#' This script will summarize correlation files that contain the correlation coefficients of predicted 
#' and measured gene expression for each miRNA - target gene pair.
#' @param [1] path to single correlation files
#' @param [2] suffix of single correlation files
#' @param [3] path where to store the correlation summary files
#' @param [4] suffix of the correlation summary files
#' @param [5] the global correlation summary files for all candidate miRNAs 
#' @export
#' @author Volker Ast
summarize_cor_files_by_mirna <- function(cor_path, cor_path_suffix, cor_summary_path, cor_summary_suffix, global_correlation_summary_file){
  #parameter testing
  if(!dir.exists(cor_path)){
    stop(paste("Dir",args[1],"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!dir.exists(cor_summary_path)){
    stop(paste("Dir",args[3],"does not exist\n",sep=" "),call.=FALSE)
  }
  
  global_mirna_vector = c()
  global_target_gene_vector = c()
  global_cor_value_vector = c()
  
  mirna_dirs = list.dirs(cor_path,full.names=FALSE,recursive=FALSE)
  
  for(p in 1:length(mirna_dirs)){     
    current_mirna = as.character(mirna_dirs[p])  
    current_mirna_mod = gsub("\\*","_star",current_mirna)
    cor_mirna_path = paste(cor_path,current_mirna_mod,"/",sep="")
    current_pattern = paste(current_mirna_mod,cor_path_suffix,sep="")
    
    cor_files = list.files(cor_mirna_path,pattern=current_pattern,full.names=FALSE)
    
    if(length(cor_files) > 0){
      target_gene_vector = c()
      cor_value_vector = c()
      
      for(i in 1:length(cor_files)){
        single_file = cor_files[i]
        target_gene = strsplit(single_file,"_")[[1]][1]
        single_df = read.table(paste(cor_mirna_path,single_file,sep=""),header=TRUE,sep="\t", stringsAsFactors = FALSE)
        mirna_index = which(single_df$mirna == current_mirna)
        if(length(mirna_index) > 0){
          cor_value = as.numeric(single_df$cor[mirna_index])
          target_gene_vector = c(target_gene_vector,target_gene)
          cor_value_vector = c(cor_value_vector,cor_value)  
          
          global_mirna_vector = c(global_mirna_vector,current_mirna)
          global_target_gene_vector = c(global_target_gene_vector,target_gene)
          global_cor_value_vector = c(global_cor_value_vector,cor_value)
        }
      }
      
      total_cor_df = data.frame(gene = target_gene_vector, cor = cor_value_vector)
      cor_summary_file = paste(cor_summary_path,current_mirna,cor_summary_suffix,sep="")
      write.table(total_cor_df,file=cor_summary_file,row.names=FALSE,sep="\t")    
    }  
  }
  #global correlation summary
  global_correlation_summary_df = data.frame(mirna = global_mirna_vector,                                           
                                             gene = global_target_gene_vector,
                                             cor = global_cor_value_vector)
  
  write.table(global_correlation_summary_df,file=global_correlation_summary_file,sep="\t",row.names=FALSE)  
}










