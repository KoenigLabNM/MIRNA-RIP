#' @import topGO
runTopGO <- function(all_genes, test_genes, current_ontology, minTargetGeneNum, sign_cutoff){
  geneList = factor(as.integer(all_genes %in% test_genes))
  names(geneList) = all_genes
    
  #Human
  regulated_tf_GOdata <- new("topGOdata",ontology = current_ontology, allGenes = geneList, nodeSize = minTargetGeneNum, annot = annFUN.org, mapping = "org.Hs.eg.db", ID = "symbol")
      
  feasible_index = which(regulated_tf_GOdata@feasible == TRUE)
  
  if(length(feasible_index) >= minTargetGeneNum){    
    allGO = topGO::usedGO(object = regulated_tf_GOdata) 
        
    resultFisher <- topGO::runTest(regulated_tf_GOdata, algorithm = "elim", statistic = "fisher")
    #resultFisher <- runTest(regulated_tf_GOdata, algorithm = "weight01", statistic = "fisher")
    #resultFisher <- runTest(regulated_tf_GOdata, algorithm = "parentchild", statistic = "fisher")
        
    allRes <- topGO::GenTable(regulated_tf_GOdata, classic = resultFisher, ranksOf = "elim", topNodes = length(allGO))
    #allRes <- GenTable(regulated_tf_GOdata, classic = resultFisher, ranksOf = "weight01", topNodes = length(allGO))
    #allRes <- GenTable(regulated_tf_GOdata, classic = resultFisher, ranksOf = "parentchild", topNodes = length(allGO))
        
    #adjust p-values
    adj_pvalues = as.vector(p.adjust(as.vector(allRes$classic),method="BH"))
    allRes$adj_p_value = adj_pvalues
    
    #get genes
    ann_genes <- topGO::genesInTerm(regulated_tf_GOdata)   
    
    sign_index = which(as.numeric(allRes$classic) <= sign_cutoff)
    if(length(sign_index) > 0){
      sign_go_terms = as.vector(allRes$GO.ID[sign_index])      
      sign_go_terms_genes = sapply(sign_go_terms,function(x){
        current_go_terms_annotated_genes = as.vector(ann_genes[[x]])
        current_go_terms_annotated_test_genes_index = which(current_go_terms_annotated_genes %in% test_genes)
        current_go_terms_annotated_test_genes = current_go_terms_annotated_genes[current_go_terms_annotated_test_genes_index]
        return(current_go_terms_annotated_test_genes)
      },simplify=F)
            
      sign_go_terms_gene_vector = as.vector(unlist(sapply(names(sign_go_terms_genes),function(x){        
        single_go_term_genes = as.vector(sign_go_terms_genes[[x]])
        single_go_term_genes_summary = paste(single_go_term_genes,collapse=",")
        return(single_go_term_genes_summary)
      })))
            
      allRes_sig = as.data.frame(allRes[sign_index,])
      allRes_sig$sign_genes = sign_go_terms_gene_vector      
      return(allRes_sig)      
    }
    else{
      return(NA)
    }
  }
  else{
    print(paste("only ",length(feasible_index)," annotated genes, no test performed"))
    return(NA)          
  }  
} 


