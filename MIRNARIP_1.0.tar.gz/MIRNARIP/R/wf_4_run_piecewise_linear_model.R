#' Piecewise linear model of miRNA expression to explain target gene expression and predict miRNA target genes
#' 
#' This script will set up a piecwise linear model for each pair of miRNA and target gene. 
#' The model is performed as #num_fold cross-validation, using the training set to estimate the parameters and the 
#' test set to calculate the predicted expression. After complete cross validation, a correlation of predicted and 
#' measured gene expression will be computed.
#' 
#' @param [1] the number of cores used for parallel computing - default to 40
#' @param [2] the number of cross validations - default to 5
#' @param [3] the number of steps to used in the model i.e. the stepsize of miRNA quantiles - default to (0, 0.2, 0.4, 0.6, 0.8, 1.0)
#' @param [4] miRNA - gene expression correlation cutoff i.e. model only target genes having a correlation with the miRNA expression below that cutoff - default to 0
#' @param [5] contraint limit for beta paramters - default to 10
#' @param [6] big M constant - default to 1000
#' @param [7] z-transformed gene expression file 
#' @param [8] file containing intersect samples of miRNA and gene expression files
#' @param [9] path where miRNA SOS type 2 value files will be stored
#' @param [10] suffix for miRNA SOS type 2 value files
#' @param [11] miRNA - gene expression correlation file
#' @param [12] mapping file of pre-miRNA IDs to miRNA IDs used in the z-transformed mirna expression file (experimental IDs)
#' @param [13] mapping file of mature miRNA IDs to pre-miRNA IDs
#' @param [14] file with candidate miRNAs to be analysed
#' @param [15] mapping file of mature miRNA IDs and its potential target genes
#' @param [16] path to store files containing the correlation of measured and predicted gene expression
#' @param [17] path to store files containing the beta- and x-parameters estimated by the model
#' @param [18] suffix of files containing the correlation of measured and predicted gene expression
#' @param [19] suffix of files containing the beta- and x-parameters estimated by the model
#' @author Volker Ast
#' @export
run_piecewise_linear_model <- function(num_cores, num_fold_cross_validation, num_mirna_expression_bin, neg_cor_cutoff, beta_m, big_m, expression_file, intersect_samples_file, mirna_bin_expression_path, mirna_bin_expression_suffix, mirna_gene_expression_cor_file, mirna_pre_exp_mapping_file, mirna_mature_pre_mapping_file, candidate_mirna_file, mirna_target_gene_file, cor_path, beta_parameter_path, output_file_suffix, result_paramter_file_suffix){
  #####
  #parameter testing
  if(!is.numeric(num_cores)){
    stop(paste("num cores parameter",num_cores,"is not a number\n",sep=" "),call.=FALSE)
  }
  if(!is.numeric(num_fold_cross_validation)){
    stop(paste("num fold crossvalidation parameter",num_fold_cross_validation,"is not a number\n",sep=" "),call.=FALSE)
  }
  if(!is.numeric(num_mirna_expression_bin)){
    stop(paste("num mirna expression bin parameter",num_mirna_expression_bin,"is not a number\n",sep=" "),call.=FALSE)
  }
  if(!is.numeric(neg_cor_cutoff)){
    stop(paste("neg cor cutoff parameter",neg_cor_cutoff,"is not a number\n",sep=" "),call.=FALSE)
  }
  if(!is.numeric(beta_m)){
    stop(paste("beta_m parameter",beta_m,"is not a number\n",sep=" "),call.=FALSE)
  }
  if(!is.numeric(big_m)){
    stop(paste("big_m parameter",big_m,"is not a number\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(expression_file)){
    stop(paste("File",expression_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(intersect_samples_file)){
    stop(paste("File",intersect_samples_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!dir.exists(mirna_bin_expression_path)){
    stop(paste("Dir",mirna_bin_expression_path,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(mirna_gene_expression_cor_file)){
    stop(paste("File",mirna_gene_expression_cor_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(mirna_pre_exp_mapping_file)){
    stop(paste("File",mirna_pre_exp_mapping_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(mirna_mature_pre_mapping_file)){
    stop(paste("File",mirna_mature_pre_mapping_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(candidate_mirna_file)){
    stop(paste("File",candidate_mirna_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(mirna_target_gene_file)){
    stop(paste("File",mirna_target_gene_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!dir.exists(cor_path)){
    stop(paste("Dir",cor_path,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!dir.exists(beta_parameter_path)){
    stop(paste("Dir",beta_parameter_path,"does not exist\n",sep=" "),call.=FALSE)
  }
  
  ###########################################
  
  #currently only one mirna per gene!
  parameter_limit = 1
    
  #register local cluster for parallelization
  cl <- parallel::makeCluster(num_cores)
  doParallel::registerDoParallel(cl)
  
  #for generation of random sample sets
  set.seed(123)
  
  ############################ Collect data
  
  #gene expression data
  expression_df = read.table(expression_file,header=TRUE,sep="\t")
  expression_matrix = as.matrix(expression_df)
  
  #intersect samples file
  intersect_samples_df = read.table(intersect_samples_file,header=FALSE,sep="\t")
  intersect_samples = as.vector(intersect_samples_df$V1)
  
  #mirna - gene expression correlation file
  mirna_gene_expression_cor_df = read.table(mirna_gene_expression_cor_file,header=TRUE,sep="\t")
  mirna_gene_expression_cor_matrix = as.matrix(mirna_gene_expression_cor_df)
  
  #miRNA mapping files
  mirna_pre_exp_mapping_df = read.table(mirna_pre_exp_mapping_file,header=TRUE,sep="\t",stringsAsFactors = FALSE)
  mirna_mature_pre_mapping_df = read.table(mirna_mature_pre_mapping_file,header=TRUE,sep="\t",stringsAsFactors = FALSE)
  
  #miRNA candidates
  candidate_mirna_df = read.table(candidate_mirna_file,header=FALSE,sep="\t")
  candidate_mirna = as.vector(candidate_mirna_df$V1)
    
  #miRNA - target genes file (i.e. from TarBase or other ressources)  
  mirna_target_gene_df = read.table(mirna_target_gene_file,header=TRUE,sep="\t",quote="\"",comment.char="",stringsAsFactors = FALSE)
  
  ######################################
  #Boolean
  USE_MIRNA = TRUE
  USE_B_BAS = FALSE
  
  #Variables
  b_bas = "b_bas"
  b_pre = "b_"
  x_pre = "x_"
  
  ##########################
  #global initialisation
  
  global_not_found_in_mirna_mapping_vector = c()
  
  ########################## Sample set
  
  #select #num_sample_exclude samples randomly
  sample_pool = intersect_samples
  num_sample_exclude = length(sample_pool) / num_fold_cross_validation
  num_sample_exclude = ceiling(num_sample_exclude)
  
  #build packages of max #num_sample_exclude samples
  iteration_vector = c()
  sample_iteration_vector = c()
  
  iteration=0
  while(length(sample_pool) >= num_sample_exclude){
    iteration = iteration + 1
    iteration_vector = c(iteration_vector,iteration)
    
    selected_samples = sample(sample_pool,num_sample_exclude)
    selected_samples_term = paste(selected_samples, collapse = ",")
    sample_iteration_vector = c(sample_iteration_vector,selected_samples_term)
    
    selected_samples_index = which(sample_pool %in% selected_samples)
    sample_pool = sample_pool[-selected_samples_index]  
  }
  #remaining samples
  if(length(sample_pool) > 0){
    iteration = iteration + 1  
    iteration_vector = c(iteration_vector,iteration)
    selected_samples = sample_pool
    selected_samples_term = paste(selected_samples, collapse = ",")
    sample_iteration_vector = c(sample_iteration_vector,selected_samples_term)
    #set sample_pool to 0
    sample_pool = c()
  }
  
  iteration_sample_df = data.frame(iteration_vector,sample_iteration_vector)
  colnames(iteration_sample_df) = c("iteration","samples")
  
  ######################################################
  
  for(p in 1:length(candidate_mirna)){  
    mirna = candidate_mirna[p]    
    #print(mirna)
    
    mirna_mod = gsub("-",".",mirna)
    mirna_mod = gsub("\\*",".",mirna_mod)
    mirna_dir_mod = gsub("\\*","_star",mirna)
    
    #lookup neg cor target genes
    mirna_neg_cor_genes = c()
    mirna_cor_index = which(colnames(mirna_gene_expression_cor_matrix) == mirna_mod)
    
    if(length(mirna_cor_index) > 0){
      neg_cor_index = which(as.vector(mirna_gene_expression_cor_matrix[,mirna_cor_index]) < neg_cor_cutoff)
      if(length(neg_cor_index) > 0){
        mirna_neg_cor_genes = as.vector(rownames(mirna_gene_expression_cor_matrix)[neg_cor_index])
      }
    }    
    
    #lookup target genes
    mirna_index = which(mirna_pre_exp_mapping_df$exp_mirna == mirna)
    if(length(mirna_index) > 0){
      pre_mirna_mapped = unique(as.vector(mirna_pre_exp_mapping_df$pre_mirna[mirna_index]))    
      
      pre_mirna_mapped_index = unique(which(mirna_mature_pre_mapping_df$pre_mirna_id == pre_mirna_mapped | mirna_mature_pre_mapping_df$mature_id == pre_mirna_mapped))
      #mature_mirna_mapped_index = which(mirna_mature_pre_mapping_df$mature_id %in% pre_mirna_mapped)
      
      if(length(pre_mirna_mapped_index) > 0){
        #if(length(mature_mirna_mapped_index) > 0){
        
        mature_mirna_mapped = as.vector(mirna_mature_pre_mapping_df$mature_id[pre_mirna_mapped_index])
        #mature_mirna_mapped = as.vector(mirna_mature_pre_mapping_df$mature_id[mature_mirna_mapped_index])          
        
        total_mirna_targets = c()
        
        #check tarBase
        for(a in 1:length(mature_mirna_mapped)){
          single_mature_mapped_mirna = mature_mirna_mapped[a]        
          tar_base_index = which(mirna_target_gene_df$miRNA == single_mature_mapped_mirna)
          if(length(tar_base_index) > 0){
            mirna_tar_base_genes = unique(as.vector(mirna_target_gene_df$target_gene[tar_base_index]))
            total_mirna_targets = c(total_mirna_targets,mirna_tar_base_genes)          
          }
          else{
            #append -5p
            single_mature_mapped_mirna_mod = paste(single_mature_mapped_mirna,"-5p",sep="")
            single_mature_mapped_mirna_mod_index = which(mirna_target_gene_df$miRNA == single_mature_mapped_mirna_mod)
            if(length(single_mature_mapped_mirna_mod_index) > 0){
              mirna_tar_base_genes = unique(as.vector(mirna_target_gene_df$target_gene[single_mature_mapped_mirna_mod_index]))
              total_mirna_targets = c(total_mirna_targets,mirna_tar_base_genes)            
            }
            else{
              #append -3p
              single_mature_mapped_mirna_mod_3p = paste(single_mature_mapped_mirna,"-3p",sep="")
              single_mature_mapped_mirna_mod_3p_index = which(mirna_target_gene_df$miRNA == single_mature_mapped_mirna_mod_3p)
              if(length(single_mature_mapped_mirna_mod_3p_index) > 0){
                mirna_tar_base_genes = unique(as.vector(mirna_target_gene_df$target_gene[single_mature_mapped_mirna_mod_3p_index]))
                total_mirna_targets = c(total_mirna_targets,mirna_tar_base_genes)              
              }
              else{
                print("Not found")              
                print(mirna)
              }
            }          
          }
        }
        
        total_target_neg_cor_index = which(total_mirna_targets %in% mirna_neg_cor_genes)
        mirna_target_genes = total_mirna_targets[total_target_neg_cor_index]
        
        if(length(mirna_target_genes) > 0){
          
          #create subfolder for mirna in cor_path and beta_parameter_path
          cor_path_mod = paste(cor_path,mirna_dir_mod,"/",sep="")
          if(!dir.exists(cor_path_mod)){
            dir.create(cor_path_mod,recursive=TRUE,mode="0777")
          }
          
          beta_parameter_path_mod = paste(beta_parameter_path,mirna_dir_mod,"/",sep="")
          if(!dir.exists(beta_parameter_path_mod)){
            dir.create(beta_parameter_path_mod,recursive=TRUE,mode="0777")
          }          
          
          foreach::foreach(s=1:length(mirna_target_genes), .export='get_correlation_by_parameter_limit_piecewise_linear', .packages="gurobi") %dopar% {          
            target_gene = mirna_target_genes[s]
            
            global_correlation_df = NA
            cor_file = paste(cor_path_mod,target_gene,"_",mirna_dir_mod,output_file_suffix,sep="")            
            
            big_M_act =  beta_m
            
            #samples with NA values in gene expression data
            na_samples = c()
            
            #expression index
            target_gene_expression_index = NA
            if(target_gene %in% rownames(expression_matrix)){
              target_gene_expression_index = which(rownames(expression_matrix) == target_gene)
              
              #identify na samples
              target_gene_expression_na_index = which(is.na(expression_matrix[target_gene_expression_index,]))
              if(length(target_gene_expression_na_index) > 0){
                na_samples = as.vector(colnames(expression_matrix)[target_gene_expression_na_index])
              }
              
            }else{      
              print("Not in gene expression data:")
              print(target_gene)
            }
            
            if(!is.na(target_gene_expression_index)){  
              ###########################################################################
              
              #initialize cor prediction df
              gene_cor_pred_df =  NULL 
              
              #initialize parameter_occurrende_df
              parameter_occurrende_df = NULL
              
              #initialize absolute error sum
              abs_error_sum = 0
              
              #initialize global correlation lists
              total_cor_pred_list = list()
              total_cor_meas_list = list()
              
              ###########################################################################  
              # set up model matrix for all samples
              num_constraints = 0      
              num_error_terms = 0
              num_parameter = 0
              num_exp_parameter = 0
              num_cons_parameter = 0
              
              constraint_matrix_colnames = c()
              binary_parameters = c()  
              mirna_binary_parameters = c()
              exp_parameters = c()
              
              
              #determine number of parameter
              #############################################################
              
              #B_BAS
              if(USE_B_BAS){
                num_parameter = num_parameter + 1
                constraint_matrix_colnames = c(constraint_matrix_colnames,b_bas)
              }
              
              #MIRNA
              if(USE_MIRNA){
                
                #define mirna_ vector                
                mirna_vector = c(mirna_dir_mod)
                
                # b_eff_miRNA_bin per miRNA and bin 
                num_parameter = num_parameter + (num_mirna_expression_bin * length(mirna_vector))
                
                # y_eff_miRNA_sample per miRNA and per sample
                num_parameter = num_parameter + (length(intersect_samples) * length(mirna_vector))
                
                # y_miRNA per miRNA
                num_parameter = num_parameter + (length(mirna_vector))
                
                # x_miRNA per miRNA
                num_parameter = num_parameter + (length(mirna_vector))
                
                #experimental parameter
                #only 1 experimental parameter per miRNA ( only binary variables)
                num_exp_parameter = num_exp_parameter + length(mirna_vector)
                
                y_mirna = paste("y_",mirna_dir_mod,sep="")                
                x_mirna = paste("x_",mirna_dir_mod,sep="")                                
                
                constraint_matrix_colnames = c(constraint_matrix_colnames,y_mirna)
                constraint_matrix_colnames = c(constraint_matrix_colnames,x_mirna)
                
                binary_parameters = c(binary_parameters,y_mirna)                        
                mirna_binary_parameters = c(mirna_binary_parameters,y_mirna)
                
                exp_parameters = c(exp_parameters,y_mirna)
                exp_parameters = c(exp_parameters,x_mirna)
                
                
                #b_eff variables
                for(o in 1:num_mirna_expression_bin){
                  eff_bin = o                  
                  b_eff_mirna = paste("b_eff_",mirna_dir_mod,"_",eff_bin,sep="")
                  constraint_matrix_colnames = c(constraint_matrix_colnames,b_eff_mirna)                          
                  exp_parameters = c(exp_parameters,b_eff_mirna)
                }
                
                #y_eff_miRNA_sample variables
                for(u in 1:length(intersect_samples)){
                  current_model_sample = intersect_samples[u]                  
                  y_eff_mirna_sample = paste("y_eff_",mirna_dir_mod,"_",current_model_sample,sep="")
                  constraint_matrix_colnames = c(constraint_matrix_colnames,y_eff_mirna_sample)
                  exp_parameters = c(exp_parameters,y_eff_mirna_sample)
                }
                
              }
              
              #construct global result matrix
              result_matrix_num_rows = parameter_limit
              result_matrix_num_cols = length(exp_parameters) + 1  
              result_parameter_matrix = matrix(0,result_matrix_num_rows,result_matrix_num_cols)
              colnames(result_parameter_matrix) = c("parameter_limit",exp_parameters)    
              parameter_limit_vector = as.vector(seq(1:parameter_limit))
              result_parameter_matrix[,"parameter_limit"] = parameter_limit_vector
              result_parameter_matrix = as.matrix(result_parameter_matrix)      
              
              
              #############################################################
              
              current_model_matrix_colnames = c(constraint_matrix_colnames)
              
              #define error terms
              for(i in 1:length(intersect_samples)){
                current_sample = intersect_samples[i]
                sample_error_term = paste("e_",current_sample,sep="")
                current_model_matrix_colnames = c(current_model_matrix_colnames,sample_error_term)
              }
              num_error_terms = length(intersect_samples)
              
              #define total column number
              total_column_number = num_parameter + num_error_terms    
              
              #############################################################
              #define number of constraints
              
              # 2 constraints for each sample (abs. value)
              # 1 for total parameter limit      
              
              num_constraints = num_constraints + (2 * length(intersect_samples)) + 1    
              
              #add additional constraints      
              if(USE_MIRNA){        
                #add constraints for each miRNA per sample
                #y_eff_j - eff_j + y_j * M' <= M'
                #y_eff_j - eff_j -y_j * M' >= -M'        
                num_constraints = num_constraints + (length(mirna_vector) * length(intersect_samples) * 2)
                
                #y_eff_j - y_j * M' <= 0
                #y_eff_j + y_j * M' >= 0        
                num_constraints = num_constraints + (length(mirna_vector) * length(intersect_samples) * 2)
                
                #b_1 - b_2 + M' * x_j <= M'
                #b_1 - b_2 + M' * x_j >= 0
                num_constraints = num_constraints + (length(mirna_vector) * (num_mirna_expression_bin - 1) * 2)          
              }
              
              #############################################################
              ###define model variables per iteration    
              #right-hand-side
              rhs = c()
              #objective vector
              obj = c()
              #fill with num_parameter x 0
              obj = c(obj,rep(0,total_column_number))
              #model sense
              modelsense = "min"
              #sense vector
              sense = c()
              #variable type
              vtype = c(rep("C",total_column_number))
              #"C" (continuous), "B" (binary), "I" (integer), "S" (semi-continuous), or "N" (semi-integer)
              #lower bound
              lb = c(rep(0,total_column_number))
              #upper bound
              ub = c(rep(0,total_column_number))
              
              #########################################################
              #constraint matrix      
              A <- matrix(0,nrow=num_constraints,ncol=total_column_number,byrow=T)
              
              current_row_index = 0
              
              colnames(A) = current_model_matrix_colnames
              names(obj) = current_model_matrix_colnames
              names(lb) = current_model_matrix_colnames
              names(ub) = current_model_matrix_colnames
              names(vtype) = current_model_matrix_colnames
              
              ##########################################################
              #define sample-independent variables and set ub and lb
              
              if(USE_MIRNA){
                if(length(mirna_vector) > 0){                    
                  for(m in 1:length(mirna_vector)){
                    miRNA = mirna_vector[m]
                    
                    #binary variable
                    y_mirna = paste("y_",miRNA,sep="")
                    #add variable type                  
                    vtype[y_mirna] = "B"
                    lb[y_mirna] = 0
                    ub[y_mirna] = 1 
                    
                    x_mirna = paste("x_",miRNA,sep="")
                    #add variable type                  
                    vtype[x_mirna] = "B"
                    lb[x_mirna] = 0
                    ub[x_mirna] = 1 
                  }
                }
              }           
              
              ###########################################################
              #add sample dependent constraints
              
              for(i in 1:length(intersect_samples)){        
                current_sample = intersect_samples[i]
                
                #create error term
                sample_error_term = paste("e_",current_sample,sep="")
                sample_error_term_index = which(colnames(A) == sample_error_term)
                #add value to obj
                sample_error_obj_index = which(names(obj) == sample_error_term)
                obj[sample_error_obj_index] = 1
                
                #add lb
                sample_error_lb_index = which(names(lb) == sample_error_term)
                lb[sample_error_lb_index] = 0
                
                #add ub
                sample_error_ub_index = which(names(ub) == sample_error_term)
                ub[sample_error_ub_index] = big_m
                
                #sample expression value
                current_sample_expression_index = which(colnames(expression_matrix) == current_sample)
                current_sample_expression_value = as.numeric(expression_matrix[target_gene_expression_index,current_sample_expression_index])
                current_sample_expression_negative_value = -(current_sample_expression_value)
                
                # add expression values (+ and -) to rhs vector        
                rhs = c(rhs,current_sample_expression_value,current_sample_expression_negative_value)
                #add sense for each expression vector
                sense = c(sense,"<=","<=")
                
                #add error terms
                A[current_row_index + 1,sample_error_term_index] = -1
                A[current_row_index + 2,sample_error_term_index] = -1 
                
                if(USE_B_BAS){
                  #always 1
                  #add to constraint_matrix
                  A[current_row_index + 1,b_bas] = 1
                  A[current_row_index + 2,b_bas] = -1
                  
                  #add bounds
                  lb[b_bas] = -big_m
                  ub[b_bas] = big_m
                }
                
                
                if(USE_MIRNA){
                  if(length(mirna_vector) > 0){
                    # 2 rows for each sample
                    # SUM {y_eff_j} -e1 <= g_1
                    # SUM {-y_eff_j} -e1 <= -g1            
                    
                    for(m in 1:length(mirna_vector)){
                      miRNA = mirna_vector[m]              
                      #continuous variable
                      y_eff_mirna_sample = paste("y_eff_",miRNA,"_",current_sample,sep="")
                      #add variable type                  
                      vtype[y_eff_mirna_sample] = "C"
                      lb[y_eff_mirna_sample] = -big_M_act
                      ub[y_eff_mirna_sample] = big_M_act                               
                      
                      #add to constraint_matrix
                      A[current_row_index + 1, y_eff_mirna_sample] = 1
                      A[current_row_index + 2, y_eff_mirna_sample] = -1
                    }
                  }      
                }       
                
                #2 lines per sample
                current_row_index = current_row_index + 2
                
                ###
                #add sample dependent constraints        
                ###        
                
                if(USE_MIRNA){
                  # y_eff_j - eff_j + y_j * M' <= M'
                  # y_eff_j - eff_j - y_j * M' >= -M'
                  
                  if(length(mirna_vector) > 0){
                    for(m in 1:length(mirna_vector)){
                      mirna = mirna_vector[m]
                      
                      #continuous variable                      
                      y_eff_mirna_sample = paste("y_eff_",mirna_dir_mod,"_",current_sample,sep="")
                      
                      A[current_row_index + 1, y_eff_mirna_sample] = 1
                      A[current_row_index + 2, y_eff_mirna_sample] = 1
                      
                      #binary variable                      
                      y_mirna = paste("y_",mirna_dir_mod,sep="")
                      
                      A[current_row_index + 1, y_mirna] = big_M_act
                      A[current_row_index + 2, y_mirna] = -big_M_act
                      
                      #get miRNA bin values
                      mirna_bin_file = paste(mirna_bin_expression_path, mirna_dir_mod, mirna_bin_expression_suffix,sep="")
                      mirna_bin_df = read.table(mirna_bin_file,header=TRUE,sep="\t")                                                           
                      mirna_bin_matrix = as.matrix(mirna_bin_df)
                      
                      current_sample_bin_index = which(rownames(mirna_bin_matrix) == current_sample)
                      if(length(current_sample_bin_index) > 0){
                        current_sample_bin_vector = as.vector(mirna_bin_matrix[current_sample_bin_index,])                        
                        bins_used_index = which(current_sample_bin_vector != 0)
                        for(u in 1:length(bins_used_index)){                  
                          current_bin = bins_used_index[u]    
                          
                          b_eff_mirna = paste("b_eff_",mirna_dir_mod,"_",current_bin,sep="")                  
                          current_bin_value = current_sample_bin_vector[current_bin]                                                      
                          current_bin_sample_product = current_bin_value
                          
                          #add to constraint_matrix
                          A[current_row_index + 1, b_eff_mirna] = -current_bin_sample_product
                          A[current_row_index + 2, b_eff_mirna] = -current_bin_sample_product
                        }
                      }
                      rhs = c(rhs,big_M_act)
                      rhs = c(rhs,-big_M_act)
                      sense = c(sense,"<=")
                      sense = c(sense,">=")
                      
                      # y_eff_j - y_j * M' <= 0
                      # y_eff_j + y_j * M' >= 0
                      #
                      A[current_row_index+3,y_eff_mirna_sample] = 1
                      A[current_row_index+3,y_mirna] = -big_M_act
                      sense = c(sense,"<=")
                      rhs = c(rhs,0)
                      
                      A[current_row_index+4,y_eff_mirna_sample] = 1
                      A[current_row_index+4,y_mirna] = big_M_act
                      sense = c(sense,">=")
                      rhs = c(rhs,0)            
                      
                      current_row_index = current_row_index + 4
                    }
                  }         
                }        
              }
              
              ###########################################################################
              #add sample-independent constraints
              
              if(USE_MIRNA){
                
                #b_1 - b_2 + M' * x_j <= 10
                #b_1 - b_2 + M' * x_j >= 0
                
                if(length(mirna_vector) > 0){
                  for(m in 1:length(mirna_vector)){
                    mirna = mirna_vector[m]            
                    x_mirna = paste("x_",mirna,sep="")
                    
                    #add constraints for all b_eff_miRNA
                    for(o in 1:(num_mirna_expression_bin-1)){                    
                      
                      b_eff_mirna = paste("b_eff_",mirna,"_",o,sep="")
                      b_eff_mirna_next = paste("b_eff_",mirna,"_",o+1,sep="")
                      
                      #b_1 - b_2 + M' * x_j <= 10
                      A[current_row_index+1,b_eff_mirna] = 1
                      A[current_row_index+1,b_eff_mirna_next] = -1
                      A[current_row_index+1,x_mirna] = beta_m
                      sense = c(sense,"<=")
                      rhs = c(rhs,beta_m)
                      
                      #b_1 - b_2 + M' * x_j >= 0
                      A[current_row_index+2,b_eff_mirna] = 1
                      A[current_row_index+2,b_eff_mirna_next] = -1
                      A[current_row_index+2,x_mirna] = beta_m
                      sense = c(sense,">=")
                      rhs = c(rhs,0)
                      
                      current_row_index = current_row_index + 2
                      
                      #add lower and upper bounds          
                      lb[b_eff_mirna] = -beta_m              
                      ub[b_eff_mirna] = beta_m            
                      
                    }            
                    #add bounds for the last b_eff_mirna bin
                    b_eff_mirna = paste("b_eff_",mirna,"_",num_mirna_expression_bin,sep="")            
                    lb[b_eff_mirna] = -beta_m
                    ub[b_eff_mirna] = beta_m            
                    
                  }
                }
              }
              
              current_row_index = current_row_index + 1
              
              ###########################################################################
              #last constraint : sum of all binary variable <= parameter_limit
              #add constraint limit for all binary parameters
              
              for(k in 1:length(binary_parameters)){
                binary_parameter = binary_parameters[k]
                binary_parameter_index = which(colnames(A) == binary_parameter)      
                A[current_row_index,binary_parameter_index] = 1      
              }
              
              #add sense to last row for parameter_limit    
              sense[current_row_index] = "<="
              
              #add current_parameter_limit to rhs
              current_parameter_limit = parameter_limit    
              rhs[current_row_index] = current_parameter_limit
              
              ###########################################################################  
              
              #iterate over all samples sets for cross validation    
              for(q in 1:length(rownames(iteration_sample_df))){
                current_cross_validation = q
                result_parameter_file = paste(beta_parameter_path_mod,target_gene,"_",mirna_dir_mod,"_cross_validation_",current_cross_validation,result_paramter_file_suffix,sep="")
                
                current_predict_sample_term = as.character(iteration_sample_df[q,2])
                current_predict_samples = as.vector(strsplit(current_predict_sample_term,",")[[1]])
                current_predict_samples = as.vector(sapply(current_predict_samples,function(x){gsub("-",".",x)}))
                
                #remove na_samples
                current_predict_samples = current_predict_samples[!current_predict_samples %in% na_samples]        
                
                #get training samples
                training_samples_index = which(!intersect_samples %in% current_predict_samples)
                training_samples = as.vector(intersect_samples[training_samples_index])
                
                #remove na samples
                training_samples = training_samples[!training_samples %in% na_samples]
                
                ###########################################################################  
                #set up model for all training samples
                
                #replace - by . in all samples
                current_model_samples = training_samples
                current_model_samples = as.vector(sapply(current_model_samples,function(x){gsub("-",".",x)}))
                
                #determine which model samples have valid expression values
                current_model_sample_index = which(colnames(expression_matrix) %in% current_model_samples)
                reduced_expression_matrix = expression_matrix[,current_model_sample_index]
                
                current_model_sample_valid_expression_value_index = which(!is.na(reduced_expression_matrix[target_gene_expression_index,]))
                current_model_samples = as.vector(colnames(reduced_expression_matrix)[current_model_sample_valid_expression_value_index])    
                
                
                #use only columns of current_model_samples 
                current_predict_samples_index = as.vector(unlist(sapply(current_predict_samples,function(x){grep(x,colnames(A))})))
                
                #check for each index which rows are affected
                rows_to_delete = as.vector(unlist(sapply(current_predict_samples_index,function(x){return(which(as.vector(A[,x]) != 0))})))
                
                rhs_na_indices = which(is.na(rhs))
                if(length(rhs_na_indices) > 0){
                  rows_to_delete = unique(c(rows_to_delete,rhs_na_indices))
                }        
                
                current_cv_A = A[-rows_to_delete,-current_predict_samples_index]
                current_cv_obj = obj[-current_predict_samples_index]
                current_cv_lb = lb[-current_predict_samples_index]
                current_cv_ub = ub[-current_predict_samples_index]
                current_cv_vtype = vtype[-current_predict_samples_index]      
                current_cv_rhs = rhs[-rows_to_delete]
                current_cv_sense = sense[-rows_to_delete]
                
                
                model <- list()
                model$A          <- current_cv_A
                model$obj        <- current_cv_obj
                model$modelsense <- modelsense
                model$rhs        <- current_cv_rhs
                model$sense      <- current_cv_sense
                model$lb         <- current_cv_lb
                model$ub         <- current_cv_ub
                model$vtype      <- current_cv_vtype
                
                
                params <- list(timeLimit = 600,OutputFlag=0)          
                result <- gurobi::gurobi(model, params)
                #print("...done")
                result_values = result$x
                names(result_values) = colnames(current_cv_A)
                result_df = data.frame(result_values)
                
                ################################################################
                #Evaluate single results
                
                for(w in 1:length(rownames(result_df))){
                  current_exp_parameter_name = rownames(result_df)[w]
                  current_exp_parameter_value = as.numeric(result_df$result_values[w])
                  current_exp_parameter_index = which(colnames(result_parameter_matrix) == current_exp_parameter_name)
                  result_parameter_matrix[parameter_limit,current_exp_parameter_index] = current_exp_parameter_value
                  
                }
                
                write.table(t(result_parameter_matrix),file=result_parameter_file,sep="\t",col.names=FALSE)
                
                #######################################################################################################
                #evaluate result_parameter_matrix
                
                #compute correlation of predicted and measured gene expression                                
                cor_vector_list = lapply(seq(1:parameter_limit),get_correlation_by_parameter_limit_piecewise_linear, result_parameter_matrix, current_predict_samples, USE_B_BAS, USE_MIRNA, expression_matrix, mirna_bin_expression_path, mirna_bin_expression_suffix, target_gene)
                
                for(r in seq(1:parameter_limit)){
                  current_cor_pred_vector = as.vector(unlist(cor_vector_list[[r]][1]))
                  current_cor_meas_vector = as.vector(unlist(cor_vector_list[[r]][2]))
                  
                  if(q == 1 & length(total_cor_pred_list) <= parameter_limit){
                    total_cor_pred_list[[r]] = current_cor_pred_vector
                    total_cor_meas_list[[r]] = current_cor_meas_vector
                  }
                  else{
                    total_cor_pred_list[[r]] = c(total_cor_pred_list[[r]],current_cor_pred_vector)
                    total_cor_meas_list[[r]] = c(total_cor_meas_list[[r]],current_cor_meas_vector)        
                  }      
                }
              }
              
              ###############################
              #compute correlation
              
              global_correlation_vector = c()
              global_correlation_mirna_vector = c()
              
              for(r in seq(1:parameter_limit)){
                total_pred_vector = as.vector(total_cor_pred_list[[r]])
                total_meas_vector = as.vector(total_cor_meas_list[[r]])
                
                current_parameter_limit_correlation = cor(total_pred_vector,total_meas_vector)    
                global_correlation_vector = c(global_correlation_vector,current_parameter_limit_correlation)
                global_correlation_mirna_vector = c(global_correlation_mirna_vector,mirna)
              }
              
              single_correlation_df = data.frame(seq(1:parameter_limit),global_correlation_mirna_vector,global_correlation_vector)
              colnames(single_correlation_df) = c("num_parameter","mirna","cor")                        
              global_correlation_df = single_correlation_df                            
              
            }else{
              print("Gene not found")
              print(target_gene)
            }            
            write.table(global_correlation_df,file=cor_file,sep="\t",row.names=FALSE)  
          }
        }else{
          print("No target genes for miRNA")
          print(matching_mirna)
        }               
      }else{
        global_not_found_in_mirna_mapping_vector = c(global_not_found_in_mirna_mapping_vector,mirna)
      }    
    }else{
      print("miRNA not found")
      print(mirna)
    }  
  }
  
  if(length(global_not_found_in_mirna_mapping_vector) > 0){
    print("Not found in mirna mapping file:")
    print(global_not_found_in_mirna_mapping_vector)
  }
  parallel::stopCluster(cl)  
}


