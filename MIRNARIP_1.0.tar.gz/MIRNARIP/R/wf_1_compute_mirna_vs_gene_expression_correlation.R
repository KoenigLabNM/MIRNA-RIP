
#' Correlate miRNA and gene expression data
#' 
#' This function computes Pearson correlation of miRNA and gene expression. It will determine the intersect samples of miRNA and gene expression matrices and save them to a file.
#' It will calculate the correlation of all miRNAs and all genes available, creating a #number_of_gene x #number_of_miRNA matrix and save it to a file.
#' @param The absolute path to miRNA expression file
#' @param The absolute path to gene expression file
#' @param The absolute path to the intersect sample file
#' @param The number of cores used for parallel computing
#' @param The absolute path and name of the correlation file
#' @author Volker Ast
#' @export
compute_mirna_gene_expression_correlation <- function(mirna_expression_file,gene_expression_file,intersect_samples_file,num_cores, mirna_gene_cor_file){
  #parameter testing
  if(!file.exists(mirna_expression_file)){
    stop(paste("File",mirna_expression_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(gene_expression_file)){
    stop(paste("File",gene_expression_file,"does not exist\n",sep=" "),call.=FALSE)
  }  
  if(!is.numeric(num_cores)){
    stop(paste("num cores parameter",num_cores,"is not a number\n",sep=" "),call.=FALSE)
  }
  
  ########################################
  
  mirna_expression_df = read.table(mirna_expression_file,header=TRUE,sep="\t")
  mirna_expression_matrix = as.matrix(mirna_expression_df)
  
  gene_expression_df = read.table(gene_expression_file,header=TRUE,sep="\t",stringsAsFactors = FALSE)
  gene_expression_matrix = as.matrix(gene_expression_df)
  
  mirna_expression_samples = as.vector(colnames(mirna_expression_matrix))
  gene_expression_samples = as.vector(colnames(gene_expression_matrix))
  
  ########################################
  
  #Intersect samples
  intersect_index = which(mirna_expression_samples %in% gene_expression_samples)
  intersect_samples = as.vector(mirna_expression_samples[intersect_index])
  #print("Intersect samples")
  #print(length(intersect_samples))
  
  #Write intersect samples file
  write(intersect_samples,file=intersect_samples_file,sep="\t")
  
  ########################################
  
  #define correlation matrix
  dim_1 = length(rownames(gene_expression_matrix))
  dim_2 = length(rownames(mirna_expression_matrix))
  
  mirna_exp_cor_matrix = matrix(0,dim_1,dim_2)
  rownames(mirna_exp_cor_matrix) = rownames(gene_expression_matrix)
  colnames(mirna_exp_cor_matrix) = rownames(mirna_expression_matrix)
  
  cc_vector_list = sapply(rownames(mirna_expression_matrix),compute_correlation_by_mirna, gene_expression_matrix, mirna_expression_matrix, intersect_samples, num_cores)
  mirna_exp_cor_matrix = as.matrix(cc_vector_list)
  write.table(mirna_exp_cor_matrix,file=mirna_gene_cor_file,sep="\t")
  
}

compute_single_correlation <- function(target_gene, mirna, gene_expression_matrix, mirna_expression_matrix, intersect_samples){
  
  mirna_index = which(rownames(mirna_expression_matrix) == mirna)
  target_gene_index = which(rownames(gene_expression_matrix) == target_gene)
  
  mirna_vector = as.vector(mirna_expression_matrix[mirna_index,intersect_samples])
  target_gene_vector = as.vector(gene_expression_matrix[target_gene_index,intersect_samples])
  
  mirna_na_indices = which(is.na(mirna_vector))
  expression_indices = which(is.na(target_gene_vector))
  total_na_indices = unique(c(mirna_na_indices,expression_indices))
  
  if(length(total_na_indices) > 0){
    mirna_vector = mirna_vector[-total_na_indices]
    target_gene_vector = target_gene_vector[-total_na_indices]    
  }
  
  if(length(mirna_vector) > 0 & length(target_gene_vector) > 0 & length(mirna_vector) == length(target_gene_vector)){
    cc = cor(mirna_vector,target_gene_vector)
    return(cc)
  }
  else{
    return(NA)
  } 
}


compute_correlation_by_mirna <- function(mirna, gene_expression_matrix, mirna_expression_matrix, intersect_samples, num_cores){  
  #cc_vector = as.vector(unlist(mclapply(rownames(expression_matrix), compute_single_correlation, mirna, expression_matrix, mc.cores=num_cores)))
  cc_vector = as.vector(unlist(parallel::mclapply(rownames(gene_expression_matrix), compute_single_correlation, mirna, gene_expression_matrix, mirna_expression_matrix, intersect_samples, mc.cores=num_cores)))
  names(cc_vector) = as.vector(rownames(gene_expression_matrix))    
  return(cc_vector)
}


