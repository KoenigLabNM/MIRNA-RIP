
#' This function computes SOS type 2 values of miRNA expression values based on user defined quantiles
#' 
#' This functions computes SOS type 2 values of miRNA expression values. Per default its 6 values in 0.2 intervals. In the output directory, it will create on output file for each miRNA in the format: <mirna>_<output_file_suffix>
#' It creates a file of all miRNAs with sufficient expression values
#' @param The absolute path to miRNA z-normalized file
#' @param The absolute path to the intersect sample file
#' @param The absolute path to the output directory
#' @param The suffix for the output files
#' @param The absolute path to the file listing all miRNAs excluding miRNAs with NA values or insufficient variance (min = median value).
#' @author Volker Ast
#' @export
compute_mirna_expression_quantiles <- function(mirna_expression_z_score_file,intersect_samples_file,output_dir,output_file_suffix,total_experimental_mirna_with_targets_and_data_file, quantiles){
  ### parameter testing
  if(!file.exists(mirna_expression_z_score_file)){
    stop(paste("File",mirna_expression_z_score_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(intersect_samples_file)){
    stop(paste("File",intersect_samples_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!dir.exists(output_dir)){
    stop(paste("Dir",output_dir,"does not exist\n",sep=" "),call.=FALSE)
  }
  
  #read data files
  all_mirna_expression_df = read.table(mirna_expression_z_score_file,header=TRUE,sep="\t")
  all_mirna_expression_matrix = as.matrix(all_mirna_expression_df)
  
  intersect_samples_df = read.table(intersect_samples_file,header=FALSE,sep="\t")
  intersect_samples = as.vector(intersect_samples_df$V1)
  
  #use only intersect samples
  all_mirna_expression_matrix = all_mirna_expression_matrix[,intersect_samples]
  
  #remove rows with na values
  any_na_index = as.vector(apply(all_mirna_expression_matrix,1,function(x){any(is.na(x))}))
  if(length(any_na_index) > 0){
    any_na_mirna = rownames(all_mirna_expression_matrix)[any_na_index]
    print("Removing rows with any NA values:")
    print(length(any_na_mirna))  
    any_na_mirna_index = which(rownames(all_mirna_expression_matrix) %in% any_na_mirna)  
    if(length(any_na_mirna_index) > 0){
      all_mirna_expression_matrix = all_mirna_expression_matrix[-any_na_mirna_index,]
    }  
  }  
  
  #check median and min values
  median_vector = as.vector(apply(all_mirna_expression_matrix,1,function(x){median(x)}))
  min_vector = as.vector(apply(all_mirna_expression_matrix,1,function(x){min(x)}))
  
  #remove rows with insufficient variance
  remove_index = c()
  
  for(i in 1:length(median_vector)){
    current_median = median_vector[i]
    current_min = min_vector[i]
    if(current_median == current_min){
      remove_index = c(remove_index,i)
    }
  }
  
  if(length(remove_index) > 0){
    print("Removing rows with median = min:")
    print(length(remove_index))  
    all_mirna_expression_matrix = all_mirna_expression_matrix[-remove_index,]
  }
  
  print("Remaining rows:")
  print(length(rownames(all_mirna_expression_matrix)))
  
  #write mirna IDs with target genes and expression data available
  write(rownames(all_mirna_expression_matrix),file=total_experimental_mirna_with_targets_and_data_file,sep="\t")
  
  #compute SOS type 2 values wih miRNA expression z-scores
  for(i in 1:length(rownames(all_mirna_expression_matrix))){  
    current_mirna = rownames(all_mirna_expression_matrix)[i]  
    current_mirna_mod = gsub("\\*","_star",current_mirna)
    
    mirna_quantile_matrix = matrix(0,length(colnames(all_mirna_expression_matrix)),length(quantiles))
    rownames(mirna_quantile_matrix) = colnames(all_mirna_expression_matrix)
    colnames(mirna_quantile_matrix) = seq(1:length(quantiles))
    
    output_file = paste(output_dir,current_mirna_mod,output_file_suffix,sep="")
    
    current_mirna_values = as.vector(all_mirna_expression_matrix[current_mirna,])
    names(current_mirna_values) = colnames(all_mirna_expression_matrix)
    
    #create modified values
    #add rnorm value to avoid division by 0
    current_mirna_values_mod = current_mirna_values
    norm_rand_values = abs(rnorm(length(current_mirna_values),0,1))
    norm_rand_values = as.vector(sapply(norm_rand_values,function(x){x*0.0001}))  
    current_mirna_values_mod = current_mirna_values_mod + norm_rand_values  
    current_mirna_quantiles = as.vector(quantile(current_mirna_values_mod,probs = quantiles))
    
    min_value = min(current_mirna_values)
    max_value = max(current_mirna_values)
    
    #check if 0% quantile < min_value
    if(current_mirna_quantiles[1] > min_value){
      current_mirna_quantiles[1] = min_value
    }
    
    #check if 100% quantile > max_value  
    if(current_mirna_quantiles[6] < max_value){
      current_mirna_quantiles[6] = max_value
    }
    
    #all values
    for(j in 1:(length(current_mirna_values))){  
      current_mirna_value = as.numeric(current_mirna_values[j])
      current_sample = names(current_mirna_values)[j]
      
      if(current_mirna_value == min_value){
        lower_index = 1
        upper_index = 2
      }
      else if(current_mirna_value == max_value){
        lower_index = 5
        upper_index = 6      
      }
      else{
        lower_index = max(which(current_mirna_quantiles <= current_mirna_value))
        upper_index = min(which(current_mirna_quantiles > current_mirna_value))
      }
      
      z_lower_bound = (current_mirna_quantiles[upper_index] - current_mirna_value) / (current_mirna_quantiles[upper_index] - current_mirna_quantiles[lower_index])
      z_upper_bound = (current_mirna_value - current_mirna_quantiles[lower_index]) / (current_mirna_quantiles[upper_index] - current_mirna_quantiles[lower_index])
      
      mirna_quantile_matrix[current_sample,lower_index] = z_lower_bound
      mirna_quantile_matrix[current_sample,upper_index] = z_upper_bound
      
    }  
    write.table(mirna_quantile_matrix,file=output_file,sep="\t")
  } 
}
