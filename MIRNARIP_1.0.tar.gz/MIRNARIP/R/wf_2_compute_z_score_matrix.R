
#' Z-transformation on a given data matrix
#' 
#' This function performs a z-normalization on a given data matrix
#' 
#' @param The absolute path to data matrix file
#' @param The absolute path to the intersect sample file
#' @param The absolute path to output file (z-transformed file)
#' @author Volker Ast
#' @export
compute_z_score_matrix <- function(expression_file, intersect_samples_file, z_score_file){
  #####
  #parameter testing
  if(!file.exists(expression_file)){
    stop(paste("File",expression_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(intersect_samples_file)){
    stop(paste("File",intersect_samples_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  
  ####################################
  
  intersect_samples_df = read.table(intersect_samples_file,header=FALSE,sep="\t")
  intersect_samples = as.vector(intersect_samples_df$V1)
    
  #read expression_file
  expression_df = read.table(expression_file,header=TRUE,sep="\t")
  expression_matrix = as.matrix(expression_df)
    
  intersect_samples_index = which(colnames(expression_matrix) %in% intersect_samples)
  if(length(intersect_samples_index) > 0){
    expression_matrix = expression_matrix[,intersect_samples_index]
  }else{
    print("No intersect samples present") 
  }
  
  #determine dimensions
  dim_1 = length(rownames(expression_matrix))
  dim_2 = length(colnames(expression_matrix))
  
  z_score_matrix = t(sapply(seq(1:dim_1),compute_z_score_row, expression_matrix))
  rownames(z_score_matrix) = rownames(expression_matrix)
  colnames(z_score_matrix) = colnames(expression_matrix)
  
  #write to file
  write.table(z_score_matrix,file = z_score_file,sep="\t")  
}

compute_z_score_single <- function(j,row_mean,row_sd){
  if(!is.na(j)){
    expression_value = as.numeric(j)
    z_score = (expression_value - row_mean) / row_sd
    return(z_score)
  }else{
    return(NA)
  }
}

compute_z_score_row <- function(i, expression_matrix){
  row_vector = as.vector(expression_matrix[i,])
  row_mean = mean(row_vector,na.rm=TRUE)
  row_sd = sd(row_vector,na.rm=TRUE)
  z_vector = as.vector(sapply(row_vector,compute_z_score_single,row_mean,row_sd))  
  return(z_vector)
}




