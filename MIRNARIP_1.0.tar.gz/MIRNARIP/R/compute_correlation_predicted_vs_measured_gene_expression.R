
get_correlation_by_parameter_limit <- function(current_parameter_limit,tresor_samples, result_parameter_matrix, expression_matrix, mirna_expression_matrix, target_gene, USE_B_BAS, USE_MIRNA, mirna_vector){  
  target_gene_expression_index = which(rownames(expression_matrix) == target_gene)
  current_result_parameter_index = which(result_parameter_matrix[,"parameter_limit",drop=FALSE] == current_parameter_limit)
  reduced_result_parameter_matrix = as.matrix(result_parameter_matrix[,-1,drop=FALSE])
  final_result_var_vector = as.vector(colnames(reduced_result_parameter_matrix))
  final_result_value_vector = as.vector(reduced_result_parameter_matrix[current_result_parameter_index,final_result_var_vector])
  result_df = data.frame(final_result_var_vector,final_result_value_vector)
  colnames(result_df) = c("var","value")
  
  predicted_value_vector = c()
  measured_value_vector = c()
  
  #predict tresor_samples
  for(i in 1:length(tresor_samples)){
    tresor_sample = tresor_samples[i]
    tresor_sample = gsub("-",".",tresor_sample)
    tresor_sample_expression_index = which(colnames(expression_matrix) == tresor_sample)
    tresor_sample_expression_value = as.numeric(expression_matrix[target_gene_expression_index,tresor_sample_expression_index])
    measured_value_vector = c(measured_value_vector,tresor_sample_expression_value)
    
    predicted_expression = 0
    
    if(USE_B_BAS){
      index = which(result_df$var == "b_bas")
      value = as.numeric(result_df$value[index])      
      predicted_expression = predicted_expression + value
    }
        
    if(USE_MIRNA){
      for(m in 1:length(mirna_vector)){
        miRNA = mirna_vector[m]
                
        b_mirna = paste("b_",miRNA,sep="")
        b_mirna_index = which(result_df$var == b_mirna)
        if(length(b_mirna_index) > 0){
          b_mirna_value = as.numeric(result_df$value[b_mirna_index])                    
          tresor_sample_miRNA_index = which(colnames(mirna_expression_matrix) == tresor_sample)
          tresor_miRNA_index = which(rownames(mirna_expression_matrix) == miRNA)
          tresor_sample_mirna_value = 0
          if(length(tresor_sample_miRNA_index) > 0 & length(tresor_miRNA_index) > 0){
            if(!is.na(mirna_expression_matrix[tresor_miRNA_index,tresor_sample_miRNA_index])){
              tresor_sample_mirna_value = as.numeric(mirna_expression_matrix[tresor_miRNA_index,tresor_sample_miRNA_index])              
            }
          }          
          mirna_product = b_mirna_value * tresor_sample_mirna_value
          predicted_expression = predicted_expression + mirna_product          
        }
      }
    }  
    predicted_value_vector = c(predicted_value_vector,predicted_expression)
  }  
  cor_pred_list = list(predicted_value_vector,measured_value_vector)
  return(cor_pred_list)
  
}

get_correlation_by_parameter_limit_piecewise_linear <- function(current_parameter_limit, result_parameter_matrix, tresor_samples, USE_B_BAS, USE_MIRNA, expression_matrix, mirna_bin_expression_path, mirna_bin_expression_suffix, target_gene){
  target_gene_expression_index = which(rownames(expression_matrix) == target_gene)
  current_result_parameter_index = which(result_parameter_matrix[,"parameter_limit",drop=FALSE] == current_parameter_limit)  
  reduced_result_parameter_matrix = as.matrix(result_parameter_matrix[,-1,drop=FALSE])  
  
  #find binary y_ parameters
  #y_ without trailing "eff"
  pattern = "^y_(?!eff)"
  y_binary_index = grep(pattern,colnames(reduced_result_parameter_matrix),perl=TRUE)
  y_binary_parameters = colnames(reduced_result_parameter_matrix)[y_binary_index]
    
  best_parameter_index = which(reduced_result_parameter_matrix[current_result_parameter_index,y_binary_parameters,drop=FALSE] != 0)
  if(length(best_parameter_index) > 0){
    best_binary_parameters = colnames(reduced_result_parameter_matrix[current_result_parameter_index,y_binary_parameters,drop=FALSE])[best_parameter_index]
        
    final_result_var_vector = c()
    final_result_value_vector = c()
    
    valid_mirna_vector = c()
    valid_tf_vector = c()
    
    if(USE_B_BAS){
      b_bas_index = which(colnames(reduced_result_parameter_matrix) == "b_bas")
      b_bas_value = as.numeric(reduced_result_parameter_matrix[current_result_parameter_index,b_bas_index])
      final_result_var_vector = c(final_result_var_vector,b_bas)
      final_result_value_vector = c(final_result_value_vector,b_bas_value)
    }
    
    if(USE_MIRNA){
      #get miRNA identifier
      mirna_terms = as.vector(sapply(best_binary_parameters,function(x){substr(x,3,nchar(x))}))
      valid_mirna_vector = c(valid_mirna_vector,mirna_terms)
      b_eff_terms = as.vector(sapply(mirna_terms,function(x){paste("b_eff_",x,sep="")}))
      b_eff_terms_index = as.vector(sapply(b_eff_terms,function(x){grep(x,colnames(reduced_result_parameter_matrix))}))
      b_eff_parameter = as.vector(colnames(reduced_result_parameter_matrix)[b_eff_terms_index])
      final_result_var_vector = c(final_result_var_vector,b_eff_parameter)
      b_eff_values = as.vector(reduced_result_parameter_matrix[current_result_parameter_index,b_eff_parameter])
      final_result_value_vector = c(final_result_value_vector,b_eff_values)
    }
    
    result_df = data.frame(final_result_var_vector,final_result_value_vector)
    colnames(result_df) = c("var","value")
    
    predicted_value_vector = c()
    measured_value_vector = c()
        
    #predict  tresor_samples
    for(i in 1:length(tresor_samples)){
      tresor_sample = tresor_samples[i]
      tresor_sample = gsub("-",".",tresor_sample)
      tresor_sample_expression_index = which(colnames(expression_matrix) == tresor_sample)
      tresor_sample_expression_value = as.numeric(expression_matrix[target_gene_expression_index,tresor_sample_expression_index])
      measured_value_vector = c(measured_value_vector,tresor_sample_expression_value)
      
      predicted_expression = 0
      
      if(USE_B_BAS){
        b_bas_index = which(result_df$var == b_bas)
        b_bas_value = as.numeric(result_df$value[b_bas_index])
        predicted_expression = predicted_expression + b_bas_value
      }
      
      if(USE_MIRNA){
        for(m in 1:length(valid_mirna_vector)){
          valid_mirna = valid_mirna_vector[m]          
          valid_mirna_mod = gsub("\\.","_",valid_mirna)        
        
          mirna_bin_file = paste(mirna_bin_expression_path, valid_mirna_mod, mirna_bin_expression_suffix,sep="")
          mirna_bin_df = read.table(mirna_bin_file,header=TRUE,sep="\t")                                     
          mirna_bin_matrix = as.matrix(mirna_bin_df)
        
          current_sample_bin_index = which(rownames(mirna_bin_matrix) == tresor_sample)
          if(length(current_sample_bin_index) > 0){
            current_sample_bin_vector = as.vector(mirna_bin_matrix[current_sample_bin_index,])
            bins_used_index = which(current_sample_bin_vector != 0)
            for(u in 1:length(bins_used_index)){                  
              current_bin = bins_used_index[u]
            
              #set b_eff_mirna_bin variable
              b_eff_mirna_bin_parameter = paste("b_eff",valid_mirna,current_bin,sep="_")
              b_eff_mirna_bin_parameter_index = which(result_df$var == b_eff_mirna_bin_parameter)
              b_eff_mirna_bin_parameter_value = as.numeric(result_df$value[b_eff_mirna_bin_parameter_index])            
            
              current_bin_value = current_sample_bin_vector[current_bin]                                                              
              current_bin_value_product = (current_bin_value * b_eff_mirna_bin_parameter_value)
              predicted_expression = predicted_expression + current_bin_value_product
            }
          }            
        }
      }
      predicted_value_vector = c(predicted_value_vector,predicted_expression)    
    }
    cor_pred_list = list(predicted_value_vector,measured_value_vector)
    return(cor_pred_list)
  }
  else{
    #y_binary_parameters is 0, eff term should not be used, no prediction    
    print(paste("Binary parameters",y_binary_parameters," have value 0, no prediction for",length(tresor_samples),"samples",sep=" "))
    
    predicted_value_vector = c(NA)
    measured_value_vector = c(NA)
    cor_pred_list = list(predicted_value_vector,measured_value_vector)
    return(cor_pred_list)
  }
}