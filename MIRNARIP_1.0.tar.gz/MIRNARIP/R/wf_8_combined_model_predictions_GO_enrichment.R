#' TopGO enrichment analysis of predicted target genes
#' 
#' This script performs a gene set enrichment analysis using predicted target genes 
#' (i.e. from the piecewise linear model, the linear model or the combined model) and gene set definitions from Gene Ontology.
#' @param [1] the script to perform TopGO enrichment
#' @param [2] number of cores to use for parallel computing
#' @param [3] miRNA - gene expression correlation file to filter out negative correlating miRNA - target gene interactions
#' @param [4] mapping file of pre-miRNA IDs to miRNA IDs used in the z-transformed mirna expression file (experimental IDs)
#' @param [5] mapping file of mature miRNA IDs to pre-miRNA IDs
#' @param [6] mapping file of mature miRNA IDs and its potential target genes
#' @param [7] prediction correlation file of the combined model
#' @param [8] path to save enrichment files
#' @param [9] enrichment file suffix
#' @param [10] minimum number of target genes per miRNA to perform enrichment - default to 5
#' @param [11] TopGO parameter node size - default to 5
#' @param [12] TopGO p-value significance cutoff for enrichments
#' @param [13] cutoff for correlation of miRNA and gene expression - default to 0
#' @param [14] cutoff for model prediction - i.e. when to assume a "good" prediction 
#' @param [15] file with candidate miRNAs to be analysed
#' @export
#' @author Volker Ast

perform_model_predictions_GO_enrichment_analysis <- function(num_cores, mirna_gene_expression_cor_file, mirna_pre_exp_mapping_file, mirna_mature_pre_mapping_file, mirna_target_gene_file, cor_summary_file, enrichment_result_path, enrichment_file_suffix, min_target_gene_num, go_node_size, top_go_sign_cutoff, neg_cor_cutoff, good_prediction_cutoff, mirna_candidates_file){
  #####
  #parameter testing
  if(!is.numeric(num_cores)){
    stop(paste(num_cores,"is not numeric\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(mirna_gene_expression_cor_file)){
    stop(paste("File",mirna_gene_expression_cor_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(mirna_pre_exp_mapping_file)){
    stop(paste("File",mirna_pre_exp_mapping_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(mirna_mature_pre_mapping_file)){
    stop(paste("File",mirna_mature_pre_mapping_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(mirna_target_gene_file)){
    stop(paste("File",mirna_target_gene_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(cor_summary_file)){
    stop(paste("File",cor_summary_file,"does not exist\n",sep=" "),call.=FALSE)
  }  
  if(!dir.exists(enrichment_result_path)){
    stop(paste("Dir",enrichment_result_path,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!is.numeric(min_target_gene_num)){
    stop(paste(min_target_gene_num,"is not numeric\n",sep=" "),call.=FALSE)
  }
  if(!is.numeric(go_node_size)){
    stop(paste(go_node_size,"is not numeric\n",sep=" "),call.=FALSE)
  }
  if(!is.numeric(top_go_sign_cutoff)){
    stop(paste(top_go_sign_cutoff,"is not numeric\n",sep=" "),call.=FALSE)
  }
  if(!is.numeric(neg_cor_cutoff)){
    stop(paste(neg_cor_cutoff,"is not numeric\n",sep=" "),call.=FALSE)
  }
  if(!is.numeric(good_prediction_cutoff)){
    stop(paste(good_prediction_cutoff,"is not numeric\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(mirna_candidates_file)){
    stop(paste("File",mirna_candidates_file,"does not exist\n",sep=" "),call.=FALSE)
  } 
  
  ##################################################################
  
  cl <- parallel::makeCluster(num_cores)
  doParallel::registerDoParallel(cl)
  
  mirna_gene_expression_cor_df = read.table(mirna_gene_expression_cor_file,header=TRUE,sep="\t")
  mirna_gene_expression_cor_matrix = as.matrix(mirna_gene_expression_cor_df)
  mirna_pre_exp_mapping_df = read.table(mirna_pre_exp_mapping_file,header=TRUE,sep="\t",stringsAsFactors = FALSE)
  mirna_mature_pre_mapping_df = read.table(mirna_mature_pre_mapping_file,header=TRUE,sep="\t",stringsAsFactors = FALSE)
  mirna_candidates_df = read.table(mirna_candidates_file,header=FALSE,sep="\t")
  candidate_mirna = as.vector(mirna_candidates_df$V1)
  cor_summary_df = read.table(cor_summary_file,header=TRUE,sep="\t",stringsAsFactors = FALSE)
  
  ######################################
  #miRNA - target genes file (i.e. from TarBase or other ressources)
  mirna_target_gene_df = read.table(mirna_target_gene_file,header=TRUE,sep="\t",quote="\"",comment.char="",stringsAsFactors = FALSE)
  
  ##################################################################
  
  global_valid_mirna = c()
  global_pattern_vector = c()
  global_gene_vector = c()
  global_num_genes_percent = c()
  all_target_genes = c()
  
  global_enrichment_df = data.frame(id = c(), name = c(), p_value = c(), p_adj = c(),  genes = c(), num_genes = c(), mirna = c(), pattern = c())
  
  foreach::foreach(i=1:length(candidate_mirna), .export="runTopGO", .packages="topGO") %dopar% {
    current_mirna = candidate_mirna[i]      
    mirna_mod = gsub("-",".",current_mirna)
    
    #lookup neg cor genes
    mirna_neg_cor_genes = c()
    mirna_cor_index = which(colnames(mirna_gene_expression_cor_matrix) == mirna_mod)
    
    if(length(mirna_cor_index) > 0){
      neg_cor_index = which(as.vector(mirna_gene_expression_cor_matrix[,mirna_cor_index]) < neg_cor_cutoff)
      if(length(neg_cor_index) > 0){
        mirna_neg_cor_genes = as.vector(rownames(mirna_gene_expression_cor_matrix)[neg_cor_index])
      }
    }
    
    #get all neg cor target genes
    mirna_target_genes = c()
    total_mirna_targets = c()
    
    mirna_index = which(mirna_pre_exp_mapping_df$exp_mirna == current_mirna)
    if(length(mirna_index) > 0){
      pre_mirna_mapped = unique(as.vector(mirna_pre_exp_mapping_df$pre_mirna[mirna_index]))    
      pre_mirna_mapped_index = which(mirna_mature_pre_mapping_df$pre_mirna_id == pre_mirna_mapped)
      if(length(pre_mirna_mapped_index) > 0){
        mature_mirna_mapped = as.vector(mirna_mature_pre_mapping_df$mature_id[pre_mirna_mapped_index])      
        
        #check miRNA - target genes
        for(a in 1:length(mature_mirna_mapped)){
          single_mature_mapped_mirna = mature_mirna_mapped[a]        
          tar_base_index = which(mirna_target_gene_df$miRNA == single_mature_mapped_mirna)
          if(length(tar_base_index) > 0){
            mirna_tar_base_genes = unique(as.vector(mirna_target_gene_df$target_gene[tar_base_index]))
            total_mirna_targets = c(total_mirna_targets,mirna_tar_base_genes)          
          }
          else{
            #append -5p
            single_mature_mapped_mirna_mod = paste(single_mature_mapped_mirna,"-5p",sep="")
            single_mature_mapped_mirna_mod_index = which(mirna_target_gene_df$miRNA == single_mature_mapped_mirna_mod)
            if(length(single_mature_mapped_mirna_mod_index) > 0){
              mirna_tar_base_genes = unique(as.vector(mirna_target_gene_df$target_gene[single_mature_mapped_mirna_mod_index]))
              total_mirna_targets = c(total_mirna_targets,mirna_tar_base_genes)            
            }
            else{
              #append -3p
              single_mature_mapped_mirna_mod_3p = paste(single_mature_mapped_mirna,"-3p",sep="")
              single_mature_mapped_mirna_mod_3p_index = which(mirna_target_gene_df$miRNA == single_mature_mapped_mirna_mod_3p)
              if(length(single_mature_mapped_mirna_mod_3p_index) > 0){
                mirna_tar_base_genes = unique(as.vector(mirna_target_gene_df$target_gene[single_mature_mapped_mirna_mod_3p_index]))
                total_mirna_targets = c(total_mirna_targets,mirna_tar_base_genes)              
              }
              else{
                print("Not found")              
                print(current_mirna)
              }
            }          
          }
        }
      }    
    }
        
    total_target_neg_cor_index = which(total_mirna_targets %in% mirna_neg_cor_genes)
    mirna_target_genes = total_mirna_targets[total_target_neg_cor_index]
    all_target_genes = c(all_target_genes, mirna_target_genes)
    
    
    #######################################################################
    ##TopGo
    
    #mirna index in cor_summary_df
    mirna_cor_index = which(cor_summary_df$mirna == current_mirna)
    
    if(length(mirna_cor_index) > 0){    
      current_mirna_cor_df = cor_summary_df[mirna_cor_index,]
      good_prediction_index = which(current_mirna_cor_df$cor >= good_prediction_cutoff)
      current_mirna_all_genes = as.vector(current_mirna_cor_df$gene[good_prediction_index])
      
      if(length(current_mirna_all_genes) >= min_target_gene_num){
        
        #######################################################################
        #enrichment for all well predicted genes (= current_mirna_all_genes)
        good_prediction_genes_enrichment_file = paste(enrichment_result_path, current_mirna, enrichment_file_suffix, sep="")
        
        # use all target genes as background
        good_prediction_genes_go_hits = runTopGO(total_mirna_targets,current_mirna_all_genes, "BP", go_node_size, top_go_sign_cutoff)
        
        # use only neg. cor. target genes as background
        #good_prediction_genes_go_hits = runTopGO(mirna_target_genes,current_mirna_all_genes, "BP", go_node_size, top_go_sign_cutoff)
        
        if(length(rownames(good_prediction_genes_go_hits)) > 0){
          write.table(good_prediction_genes_go_hits,file=good_prediction_genes_enrichment_file,row.names=FALSE,sep="\t")
        }      
      }    
    }  
  }
  
  parallel::stopCluster(cl)  
}




