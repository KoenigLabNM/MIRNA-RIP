
#' This script combines the prediction correlation of the linear and the piecewise linear model
#' For each modeled miRNA - targe gene pair, it compares the correlation of predicted and measured 
#' gene expression from the linear and the piecewise linear model and uses the higher correlation coefficient.
#' 
#' @param [1] file containing all prediction correlations of the linear model
#' @param [2] file containing all prediction correlations of the piecewise linear model
#' @param [3] file containing all prediction correlations of the combined model
#' @export
#' @author Volker Ast
create_combined_model_correlation_file <- function(lin_cor_summary_file, pwl_cor_summary_file, combined_cor_summary_file){
  
  #####
  #parameter testing
  if(!file.exists(lin_cor_summary_file)){
    stop(paste("File",lin_cor_summary_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  if(!file.exists(pwl_cor_summary_file)){
    stop(paste("File",pwl_cor_summary_file,"does not exist\n",sep=" "),call.=FALSE)
  }
  
  global_cor_file_1 = lin_cor_summary_file
  global_cor_file_2 = pwl_cor_summary_file
  
  
  global_cor_df_1 = read.table(global_cor_file_1,header=TRUE,sep="\t")
  
  na_index_1 = which(is.na(global_cor_df_1$cor))
  if(length(na_index_1) > 0){
    global_cor_df_1 = global_cor_df_1[-na_index_1,]
  }
  
  global_cor_df_2 = read.table(global_cor_file_2,header=TRUE,sep="\t")
  
  na_index_2 = which(is.na(global_cor_df_2$cor))
  if(length(na_index_2) > 0){
    global_cor_df_2 = global_cor_df_2[-na_index_2,]
  }
  
  merged_df = merge(global_cor_df_1,global_cor_df_2,by=c("mirna","gene"))
  colnames(merged_df) = c("mirna","gene","cor_lin","cor_pwl")
  
  combined_cor_vector = c()
  
  for(i in 1:length(rownames(merged_df))){
    cor_1 = as.numeric(merged_df$cor_lin[i])
    cor_2 = as.numeric(merged_df$cor_pwl[i])
    
    if(cor_1 > cor_2){
      combined_cor_vector = c(combined_cor_vector,cor_1)
    }else if(cor_1 < cor_2){
      combined_cor_vector = c(combined_cor_vector,cor_2)
    }else if(cor_1 == cor_2){
      combined_cor_vector = c(combined_cor_vector,cor_1)
    }    
  }
  
  combined_cor_df = merged_df[,c(1,2)]
  combined_cor_df$cor = combined_cor_vector
  write.table(combined_cor_df,file=combined_cor_summary_file,sep="\t",row.names=FALSE)
    
}





